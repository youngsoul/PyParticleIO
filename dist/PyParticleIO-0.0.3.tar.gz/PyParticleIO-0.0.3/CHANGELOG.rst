Changelog
=========

The third digit is only for regressions.


----

0.0.1 (2016-25-03)
------------------

Changes:
^^^^^^^^

Initial Release and implementation

0.0.2 (2016-25-03)
------------------

Changes:
^^^^^^^^

* Added all_devices attribute to ParticleCloud to return a collection of all of the devices
  Used like:  all_particle_devices = my_particle_cloud.all_devices
