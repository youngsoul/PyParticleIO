Changelog
=========

The third digit is only for regressions.


----

0.0.2 (2016-25-03)
------------------

Changes:
^^^^^^^^

Initial Release and implementation


0.0.3 (2016-25-03)
------------------

Changes:
^^^^^^^^
* Added all_devices attribute to ParticleCloud to return a collection of all of the devices
  Used like:  all_particle_devices = my_particle_cloud.all_devices


0.0.4 (2016-25-03)
------------------

Changes:
^^^^^^^^
* removed all_devices attribute because the user can use my_particle_cloud.devices

0.0.5 (2016-31-03)
------------------

Changes:
^^^^^^^^
* documentation update

0.0.6 (2016-31-03)
------------------

Changes:
^^^^^^^^
* documentation update
